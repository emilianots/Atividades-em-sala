

class Elevador {
    private _capacidade: number;
    private _lotacao: number;
    private _andarAtual: number;
    private _andaresPredio: number;

    constructor(capacidade: number, andarPredio: number) {
        this._capacidade = capacidade;
        this._andaresPredio = andarPredio;
        this._lotacao = 0;
        this._andarAtual = 0;
    }

    public entrar(qtd:number){
        if((this._lotacao + qtd) > this._capacidade){
            console.log("capacidade maxima");
            return;
        }
        this._lotacao += qtd;
        console.log(this._lotacao)
    }

}

let el = new Elevador(10, 25);

el.entrar(2);
el.entrar(4);
el.entrar(5);
el.entrar(2);
el.entrar(3);
"use strict";
class Televisao {
    constructor() {
        this._nCanal = 0;
        this._nVolume = 0;
    }
    get nCanal() {
        return this._nCanal;
    }
    get nVolume() {
        return this._nVolume;
    }
    changeVolume(value) {
        value ? this._nVolume++ : this._nCanal--;
    }
    changeCanal(value) {
        value ? this._nCanal++ : this._nVolume--;
    }
    goToCanal(value) {
        value >= 0 ? this._nCanal = value : console.log("Erro");
    }
    toString() {
        return `Canal: ${this.nCanal} \nVolume: ${this.nVolume}\n`;
    }
}
class Controle {
    constructor() {
        this._tv = new Televisao();
    }
    changeCanal(value) {
        this._tv.changeCanal(value);
        console.log("" + this._tv);
    }
    changeVolume(value) {
        this._tv.changeVolume(value);
        console.log("" + this._tv);
    }
    goToCanal(value) {
        this._tv.goToCanal(value);
        console.log("" + this._tv);
    }
}
let c = new Controle();
for (let i = 0; i < 3; i++) {
    c.changeCanal(true);
}
for (let i = 0; i < 3; i++) {
    c.changeVolume(true);
}
c.goToCanal(50);
